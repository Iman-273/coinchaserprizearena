
// Mock Supabase client for development
// This will be replaced when you connect to actual Supabase

export interface Session {
  user: {
    id: string;
    email?: string;
  };
}

export interface AuthResponse {
  data: { session: Session | null };
  error: any;
}

export interface User {
  id: string;
  email?: string;
}

// Global auth state listeners
let authCallbacks: ((event: string, session: Session | null) => void)[] = [];

// Mock authentication methods
const mockAuth = {
  getSession: async (): Promise<AuthResponse> => {
    const session = localStorage.getItem('mock-session');
    return {
      data: { session: session ? JSON.parse(session) : null },
      error: null
    };
  },
  
  signUp: async ({ email, password }: { email: string; password: string }) => {
    // Mock sign up - create a session and trigger auth change
    console.log('Mock sign up:', email);
    const mockSession: Session = {
      user: { id: 'mock-user-' + Date.now(), email }
    };
    localStorage.setItem('mock-session', JSON.stringify(mockSession));
    
    // Trigger auth state change for all listeners
    setTimeout(() => {
      authCallbacks.forEach(callback => {
        callback('SIGNED_IN', mockSession);
      });
    }, 100);
    
    return { error: null };
  },
  
  signInWithPassword: async ({ email, password }: { email: string; password: string }) => {
    // Mock sign in - create a fake session
    console.log('Mock sign in:', email);
    const mockSession: Session = {
      user: { id: 'mock-user-' + Date.now(), email }
    };
    localStorage.setItem('mock-session', JSON.stringify(mockSession));
    
    // Trigger auth state change for all listeners
    setTimeout(() => {
      authCallbacks.forEach(callback => {
        callback('SIGNED_IN', mockSession);
      });
    }, 100);
    
    return { error: null };
  },
  
  signOut: async () => {
    localStorage.removeItem('mock-session');
    
    // Trigger auth state change for all listeners
    setTimeout(() => {
      authCallbacks.forEach(callback => {
        callback('SIGNED_OUT', null);
      });
    }, 100);
    
    return { error: null };
  },
  
  onAuthStateChange: (callback: (event: string, session: Session | null) => void) => {
    // Add callback to global list
    authCallbacks.push(callback);
    
    // Immediately check for existing session
    const session = localStorage.getItem('mock-session');
    setTimeout(() => {
      callback('SIGNED_IN', session ? JSON.parse(session) : null);
    }, 100);
    
    return {
      data: {
        subscription: {
          unsubscribe: () => {
            // Remove callback from global list
            authCallbacks = authCallbacks.filter(cb => cb !== callback);
            console.log('Mock unsubscribe');
          }
        }
      }
    };
  }
};

// Mock database methods
const mockFrom = (table: string) => ({
  select: (columns = '*') => ({
    eq: (column: string, value: any) => ({
      single: async () => {
        // Return mock profile data
        if (table === 'profiles') {
          return {
            data: {
              id: 'mock-user-' + Date.now(),
              username: 'Player',
              total_coins: 0,
              tournament_active: false,
              created_at: new Date().toISOString()
            },
            error: null
          };
        }
        return { data: null, error: { code: 'PGRST116' } };
      }
    })
  }),
  
  insert: (data: any) => ({
    select: () => ({
      single: async () => ({
        data: { ...data, created_at: new Date().toISOString() },
        error: null
      })
    })
  }),
  
  update: (data: any) => ({
    eq: (column: string, value: any) => ({
      select: () => ({
        single: async () => ({
          data: { ...data, id: value },
          error: null
        })
      })
    })
  })
});

// Mock Supabase client
export const supabase = {
  auth: mockAuth,
  from: mockFrom
};
