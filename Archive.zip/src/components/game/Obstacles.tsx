import { useRef, useState, useEffect } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';
import { v4 as uuidv4 } from 'uuid';

const lanePositions = [-1.5, 0, 1.5];
const spawnZ = -40;
const speed = 0.1;

type ObstacleInstance = {
  id: string;
  mesh: THREE.Object3D;
};

export default function Obstacles() {
  const groupRef = useRef<THREE.Group>(null);
  const [obstacles, setObstacles] = useState<ObstacleInstance[]>([]);

  // Load multiple models
  const modelRoadCone = useGLTF('/models/RoadCone.glb');
  const modelGoldBag = useGLTF('/models/GoldBag.glb');
  const modelTree = useGLTF('/models/TwistedTree.glb');

//   const models = [modelRoadCone.scene, modelGoldBag.scene, modelTree.scene];
// Instead of just an array of scenes
const models = [
    { scene: modelRoadCone.scene, scale: 0.7 },
    { scene: modelGoldBag.scene, scale: 1.0 },
    { scene: modelTree.scene, scale: 0.4 }, // smaller trees
  ];
  
//   const spawnObstacle = () => {
//     const lane = lanePositions[Math.floor(Math.random() * lanePositions.length)];
//     const id = uuidv4();
//     const baseModel = models[Math.floor(Math.random() * models.length)];
//     const mesh = baseModel.clone(true); // Deep clone

//     mesh.position.set(lane, 0, spawnZ);
//     mesh.scale.set(0.5, 0.5, 0.5); // Adjust as needed

//     setObstacles((prev) => [...prev, { id, mesh }]);
//   };
const spawnObstacle = () => {
    const lane = lanePositions[Math.floor(Math.random() * lanePositions.length)];
    const id = uuidv4();
    const { scene, scale } = models[Math.floor(Math.random() * models.length)];
  
    const mesh = scene.clone(true);
    mesh.position.set(lane, 0, spawnZ);
    mesh.scale.set(scale, scale, scale); // 🔥 Apply individual scale
  
    setObstacles((prev) => [...prev, { id, mesh }]);
  };
  
  useEffect(() => {
    const interval = setInterval(() => {
      spawnObstacle();
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  // Move forward
  useFrame(() => {
    setObstacles((prev) =>
      prev.filter(({ mesh }) => {
        mesh.position.z += speed;
        return mesh.position.z < 10;
      })
    );
  });

  return (
    <group ref={groupRef}>
      {obstacles.map(({ id, mesh }) => (
        <primitive key={id} object={mesh} />
      ))}
    </group>
  );
}
useGLTF.preload('/models/RoadCone.glb');
useGLTF.preload('/models/GoldBag.glb');
useGLTF.preload('/models/TwistedTree.glb');
