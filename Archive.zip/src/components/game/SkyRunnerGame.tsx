
import { useState, useEffect, useRef, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, RotateCcw, ArrowUp, ArrowDown, Trophy, Play, Coins, Star } from "lucide-react";
import GameWorld from "./GameWorld";

interface SkyRunnerGameProps {
  onGameEnd: (score: number) => void;
  profile: any;
  isTournament: boolean;
}

export const SkyRunnerGame = ({ onGameEnd, profile, isTournament }: SkyRunnerGameProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const gameLoopRef = useRef<number>();
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  // const [gameStarted, setGameStarted] = useState(false);
  const [gameStarted, setGameStarted] = useState(false);
  const [gameMode, setGameMode] = useState<"free" | "tournament">("free");

  const startGame = (mode: "free" | "tournament") => {
    setGameMode(mode);
    setGameStarted(true);
  };

  const endGame = (score: number) => {
    setGameStarted(false);
    // Handle score submission and profile updates here
    console.log(`Game ended with score: ${score}, mode: ${gameMode}`);
  };
  if (!gameStarted) {
    return (
      <div className="p-4 space-y-6">
        <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">Sky Runner</h1>
        <p className="text-blue-200">Escape the hurdles, collect coins, win prizes!</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardContent className="p-4 text-center">
            <Coins className="h-8 w-8 text-yellow-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">{profile?.total_coins || 0}</p>
            <p className="text-sm text-blue-200">Total Coins</p>
          </CardContent>
        </Card>
        
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardContent className="p-4 text-center">
            <Trophy className="h-8 w-8 text-purple-400 mx-auto mb-2" />
            <p className="text-2xl font-bold text-white">
              {profile?.tournament_active ? "Active" : "Inactive"}
            </p>
            <p className="text-sm text-blue-200">Tournament</p>
          </CardContent>
        </Card>
      </div>

      {/* Game Modes */}
      <div className="space-y-4">
        <Card className="bg-gradient-to-r from-green-500/20 to-blue-500/20 backdrop-blur-sm border-green-400/30">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Play className="h-5 w-5" />
              Free Play
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-blue-800 text-sm">
              Practice your skills! Free play doesn't count toward tournament rankings but helps you improve.
            </p>
            <Button 
              onClick={() => startGame("free")}
              className="w-full bg-green-500 hover:bg-green-600 font-bold"
            >
              Start Free Game
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border-yellow-400/30">
          <CardHeader>
            <CardTitle className=" flex items-center gap-2">
              <Star className="h-5 w-5" />
              Tournament Play
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-blue-00 text-sm">
              {profile?.tournament_active 
                ? "You're in! Your scores count toward weekly rankings and prizes."
                : "Join the tournament for $2 and compete for weekly prizes up to $5,000!"
              }
            </p>
            <Button 
              onClick={() => startGame("tournament")}
              disabled={!profile?.tournament_active}
              className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600 text-white font-bold disabled:opacity-50"
            >
              {profile?.tournament_active ? "Start Tournament Game" : "Join Tournament First"}
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Game Rules */}
      <Card className="bg-white/5 backdrop-blur-sm border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg">🎮 How to Play</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="text-blue-200 text-sm space-y-1">
            <p>• Tap to jump and avoid obstacles</p>
            <p>• Collect golden coins to increase your score</p>
            <p>• Survive as long as possible on the sky road</p>
            <p>• Tournament scores count toward weekly rankings</p>
          </div>
        </CardContent>
      </Card>
    
       
      </div>
    );
  }else{

    return (
      <div className="w-full h-screen flex flex-col items-center justify-center bg-gray-900">
    <GameWorld />
    </div>
    )
  }

};
