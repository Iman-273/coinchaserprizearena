
// import { useRef, useMemo, useEffect } from 'react';
// import { useFrame } from '@react-three/fiber';
// import { useGLTF } from '@react-three/drei';
// import * as THREE from 'three';

// const TILE_BEHIND = 30;
// const TILE_AHEAD = 90;
// const TILE_TOTAL = TILE_BEHIND + TILE_AHEAD;
// const TILE_LENGTH = 1;
// const SPEED = 0.1;
// const laneXPositions = [-2.2, 0, 2.2];
// const POOL_SIZE = 30;
// const SIDE_OFFSET = 5.2;

// let score = 0;

// export default function GroundTiles({ setRefs }: { setRefs: (refs: THREE.Object3D[]) => void }) {
//   const groupRef = useRef<THREE.Group>(null);
//   const poolRef = useRef<THREE.Object3D[]>([]);
//   const activeObstaclesRef = useRef<THREE.Object3D[]>([]);
//   const offsetRef = useRef(0);

//   const { scene: roadModel } = useGLTF('/models/PathStraight.glb');
//   const { scene: coneModel } = useGLTF('/models/RoadCone.glb');
//   const { scene: treeModel } = useGLTF('/models/DeadTrees.glb');
//   const { scene: coinModel } = useGLTF('/models/GoldBag.glb');
//   const { scene: buildingModel1 } = useGLTF('/models/LargeBuilding.glb');
//   const { scene: buildingModel2 } = useGLTF('/models/LargeBuilding2.glb');
//   const { scene: grassModel } = useGLTF('/models/GrassTile.glb');

//   const models = useMemo(() => [
//     { scene: coneModel, yOffset: -1, scale: 1.6, type: 'obstacle' },
//     { scene: treeModel, yOffset: -1, scale: 0.2, type: 'decoration' },
//     { scene: coinModel, yOffset: -1, scale: 1.9, type: 'coin' },
//   ], [coneModel, treeModel, coinModel]);

//   const roadTiles = useMemo(() => {
//     const tiles: THREE.Object3D[] = [];

//     for (let lane = 0; lane < laneXPositions.length; lane++) {
//       for (let i = -TILE_BEHIND; i < TILE_AHEAD; i++) {
//         const tile = roadModel.clone(true);
//         tile.scale.set(1.9, 1.9, 1.9);
//         tile.rotation.set(0, Math.PI * 1.5, 0);
//         // tile.position.set(0, -1, i * -TILE_LENGTH);
//         tile.position.set(0, -1, -i * TILE_LENGTH);  
//         tiles.push(tile);
//       }
//     }

//     for (let i = -TILE_BEHIND; i < TILE_AHEAD; i++) {
//       const grassLeft = grassModel.clone(true);
//       grassLeft.position.set(laneXPositions[0] - SIDE_OFFSET, -1.5, i * -TILE_LENGTH);
//       grassLeft.scale.set(2.5, 2.5, 2.5);
//       tiles.push(grassLeft);

//       const grassRight = grassModel.clone(true);
//       grassRight.position.set(laneXPositions[2] + SIDE_OFFSET, -1.5, i * -TILE_LENGTH);
//       grassRight.scale.set(2.5, 2.5, 2.5);
//       tiles.push(grassRight);
//     }

//     for (let i = -TILE_BEHIND; i < TILE_AHEAD; i += 2) {
//       const treeL = treeModel.clone(true);
//       const treeR = treeModel.clone(true);
//       const size = 0.4 + Math.random() * 0.5;
//       treeL.scale.set(size, size, size);
//       treeR.scale.set(size, size, size);
//       treeL.position.set(laneXPositions[0] - 50, -0.8, -i * -TILE_LENGTH);
//       treeR.position.set(laneXPositions[2] + SIDE_OFFSET, -0.8, i * -TILE_LENGTH);
//       tiles.push( treeL,treeR);
//     }

//     for (let i = -TILE_BEHIND; i < TILE_AHEAD; i += 5) {
//       const buildingL = (i % 10 === 0 ? buildingModel1 : buildingModel2).clone(true);
//       const buildingR = (i % 10 === 0 ? buildingModel2 : buildingModel1).clone(true);
//       buildingL.position.set(laneXPositions[0] - (SIDE_OFFSET + 2.5), -1, i * -TILE_LENGTH);
//       buildingL.scale.set(1.9, 1.9, 1.9);
//       buildingR.position.set(laneXPositions[2] + (SIDE_OFFSET + 2.5), -1, i * -TILE_LENGTH);
//       buildingR.scale.set(1.9, 1.9, 1.9);
//       tiles.push(buildingL, buildingR);
//     }

//     return tiles;
//   }, [roadModel, treeModel, buildingModel1, buildingModel2, grassModel]);

//   const spawnObstacles = () => {
//     const usedLanes = new Set<number>();
//     const count = Math.floor(Math.random() * 2) + 1;

//     for (let i = 0; i < count; i++) {
//       let laneIdx;
//       do {
//         laneIdx = Math.floor(Math.random() * laneXPositions.length);
//       } while (usedLanes.has(laneIdx));
//       usedLanes.add(laneIdx);

//       const item = models[Math.floor(Math.random() * models.length)];
//       const mesh = poolRef.current.length > 0 ? poolRef.current.pop()! : item.scene.clone(true);
//       mesh.userData.type = item.type;
//       mesh.position.set(laneXPositions[laneIdx], -1, -TILE_AHEAD * TILE_LENGTH);
//       // mesh.scale.set(item.scale, item.scale, item.scale);
//       mesh.visible = true;
//       activeObstaclesRef.current.push(mesh);
//     }

//     setRefs(activeObstaclesRef.current);
//   };

//   useEffect(() => {
//     for (let i = 0; i < POOL_SIZE; i++) {
//       const model = models[i % models.length];
//       const mesh = model.scene.clone(true);
//       mesh.visible = false;
//       poolRef.current.push(mesh);
//     }

//     const interval = setInterval(spawnObstacles, 1000);
//     return () => clearInterval(interval);
//   }, []);

//   useFrame((_, delta) => {
//     const speed = SPEED * delta * 60;
//     offsetRef.current += speed;

//     roadTiles.forEach((tile) => {
//       tile.position.z += speed;
//       if (tile.position.z > TILE_LENGTH * TILE_BEHIND) {
//         tile.position.z -= TILE_LENGTH * TILE_TOTAL;
//       }
//     });

//     activeObstaclesRef.current = activeObstaclesRef.current.filter((mesh) => {
//       mesh.position.z += speed;

//       // Simple collision detection (demo purposes only)
//       const playerZ = 2;
//       if (Math.abs(mesh.position.z - playerZ) < 0.2) {
//         if (mesh.userData.type === 'coin') {
//           score++;
//           console.log('Coin collected. Score:', score);
//         } else if (mesh.userData.type === 'obstacle') {
//           alert(`💥 Collision! Game Over\nFinal Score: ${score}`);
//           score = 0;
//         }
//         mesh.visible = false;
//         poolRef.current.push(mesh);
//         return false;
//       }

//       if (mesh.position.z >= 10) {
//         mesh.visible = false;
//         poolRef.current.push(mesh);
//         return false;
//       }

//       return true;
//     });
//   });

//   return (
//     <group ref={groupRef}>
//       {roadTiles.map((tile, i) => <primitive key={`tile-${i}`} object={tile} />)}
//       {[...activeObstaclesRef.current, ...poolRef.current].map((mesh, i) => (
//         <primitive key={`obstacle-${i}`} object={mesh} />
//       ))}
//     </group>
//   );
// }

// useGLTF.preload('/models/PathStraight.glb');
// useGLTF.preload('/models/RoadCone.glb');
// useGLTF.preload('/models/DeadTrees.glb');
// useGLTF.preload('/models/GoldBag.glb');
// useGLTF.preload('/models/LargeBuilding.glb');
// useGLTF.preload('/models/LargeBuilding2.glb');
// useGLTF.preload('/models/GrassTile.glb');



// import { useRef, useMemo, useEffect, useCallback } from 'react';
// import { useFrame } from '@react-three/fiber';
// import { useGLTF } from '@react-three/drei';
// import * as THREE from 'three';

// /* -------------------------------------------------------------------------- */
// /*                                  CONFIG                                    */
// /* -------------------------------------------------------------------------- */

// const TILE_LENGTH = 1;
// const TILES_BEHIND = 30;
// const TILES_AHEAD = 90;
// const SPEED = 0.1;                        // world‑space units / frame (at 60 fps)

// const LANES_X = [-2.2, 0, 2.2];           // three lane system (L‑C‑R)
// const COLLISION_Z = 0.75;                 // forward/behind tolerance
// const COLLISION_X = 0.75;                 // left/right tolerance

// const SPAWN_EVERY_MS = 1000;              // obstacle spawn cadence
// const POOL_SIZE = 40;                     // pooled meshes (obstacles + coins)

// /* -------------------------------------------------------------------------- */
// /*                            GROUND‑TILE COMPONENT                           */
// /* -------------------------------------------------------------------------- */

// export interface GroundTilesProps {
//   /** current player position (world‑space) – supplied by the parent */
//   playerPos: THREE.Vector3;
//   /** callback so the parent can receive a list of active obstacles */
//   setRefs?: (refs: THREE.Object3D[]) => void;
// }

// export default function GroundTiles({ playerPos, setRefs }: GroundTilesProps) {
//   /* ------------------------------- references ------------------------------ */
//   const offsetZ = useRef(0);                         // accumulated scroll offset
//   const pool = useRef<THREE.Object3D[]>([]);         // inactive meshes
//   const active = useRef<THREE.Object3D[]>([]);       // active (in‑scene) meshes

//   /* -------------------------------- models -------------------------------- */
//   const { scene: road }      = useGLTF('/models/PathStraight.glb');
//   const { scene: cone }      = useGLTF('/models/RoadCone.glb');
//   const { scene: tree }      = useGLTF('/models/DeadTrees.glb');
//   const { scene: coin10 }      = useGLTF('/models/GoldBag.glb');
//   const { scene: coin }      = useGLTF('/models/coin.glb');
//   const { scene: grass }     = useGLTF('/models/GrassTile.glb');

//   const obstacles = useMemo(() => [
//     { scene: cone, scale: 1.6,   type: 'obstacle' },
//     { scene: coin, scale: 1.9,   type: 'coin'     },
//   ], [cone, coin]);

//   /* --------------------------- static background --------------------------- */
//   const background = useMemo(() => {
//     const tiles: THREE.Object3D[] = [];

//     for (let i = -TILES_BEHIND; i < TILES_AHEAD; i++) {
//       const tile = road.clone();
//       tile.rotation.set(0, Math.PI * 1.5, 0);
//       tile.scale.setScalar(1.9);
//       tile.position.set(0, -1, -i * TILE_LENGTH);
//       tiles.push(tile);

//       // grass L/R
//       const gL = grass.clone();
//       const gR = grass.clone();
//       gL.scale.setScalar(2.4);
//       gR.scale.setScalar(2.4);
//       gL.position.set(LANES_X[0] - 5, -1.5, -i * TILE_LENGTH);
//       gR.position.set(LANES_X[2] + 5, -1.5, -i * TILE_LENGTH);
//       tiles.push(gL, gR);
//     }

//     return tiles;
//   }, [road, grass]);

//   /* ------------------------------- helpers -------------------------------- */
//   const acquireMesh = useCallback(() => {
//     if (pool.current.length) return pool.current.pop()!;
//     const { scene, scale, type } = obstacles[Math.floor(Math.random() * obstacles.length)];
//     const m = scene.clone();
//     m.userData.type = type;
//     m.scale.setScalar(scale);
//     return m;
//   }, [obstacles]);

//   const releaseMesh = useCallback((m: THREE.Object3D) => {
//     m.visible = false;
//     pool.current.push(m);
//   }, []);

//   /* ------------------------- obstacle spawn routine ------------------------ */
//   const spawn = useCallback(() => {
//     const lanesUsed = new Set<number>();
//     const toSpawn = Math.floor(Math.random() * 2) + 1; // 1‑2 per cycle

//     for (let i = 0; i < toSpawn; i++) {
//       let laneIdx;
//       do laneIdx = Math.floor(Math.random() * LANES_X.length);
//       while (lanesUsed.has(laneIdx));
//       lanesUsed.add(laneIdx);

//       const obj = acquireMesh();
//       obj.visible = true;
//       obj.position.set(LANES_X[laneIdx], -1, -(TILES_AHEAD - 2) * TILE_LENGTH);
//       active.current.push(obj);
//     }

//     setRefs?.(active.current);
//   }, [acquireMesh, setRefs]);

//   /* ------------------------------ initial pool ----------------------------- */
//   useEffect(() => {
//     for (let i = 0; i < POOL_SIZE; i++) pool.current.push(acquireMesh());
//     const id = setInterval(spawn, SPAWN_EVERY_MS);
//     return () => clearInterval(id);
//   }, [acquireMesh, spawn]);

//   /* ----------------------------- game loop -------------------------------- */
//   const scoreRef = useRef(0);

//   useFrame((_, delta) => {
//     const dz = SPEED * delta * 60; // frame‑rate‑independent scroll
//     offsetZ.current += dz;

//     /* move ground */
//     background.forEach(tile => {
//       tile.position.z += dz;
//       if (tile.position.z > TILES_BEHIND * TILE_LENGTH) tile.position.z -= (TILES_BEHIND + TILES_AHEAD) * TILE_LENGTH;
//     });

//     /* move / test active obstacles */
//     active.current = active.current.filter(obj => {
//       obj.position.z += dz;

//       // cull when behind camera
//       if (obj.position.z > 5) { releaseMesh(obj); return false; }

//       /* basic AABB collision */
//       const dzCol = Math.abs(obj.position.z - playerPos.z) < COLLISION_Z;
//       const dxCol = Math.abs(obj.position.x - playerPos.x) < COLLISION_X;

//       if (dzCol && dxCol) {
//         if (obj.userData.type === 'coin') {
//           scoreRef.current += 1;
//           // You can lift this to state if you need UI re‑render
//         } else {
//           alert(`💥 Collision! Final score: ${scoreRef.current}`);
//           scoreRef.current = 0;
//         }
//         releaseMesh(obj);
//         return false;
//       }
//       return true;
//     });
//   });

//   /* -------------------------------- render -------------------------------- */
//   return (
//     <group>
//       {background.map((obj, i) => <primitive key={`bg-${i}`} object={obj} />)}
//       {[...active.current, ...pool.current].map((m, i) => (
//         <primitive key={`mesh-${i}`} object={m} />
//       ))}
//     </group>
//   );
// }

// /* -------------------------------------------------------------------------- */
// /*                              ASSET PRELOADS                                */
// /* -------------------------------------------------------------------------- */

// useGLTF.preload('/models/PathStraight.glb');
// useGLTF.preload('/models/RoadCone.glb');
// useGLTF.preload('/models/DeadTrees.glb');
// useGLTF.preload('/models/GoldBag.glb');
// useGLTF.preload('/models/GrassTile.glb');
// useGLTF.preload('/models/LargeBuilding.glb');
// useGLTF.preload('/models/coin.glb');




// import { useRef, useMemo, useEffect, useCallback } from 'react';
// import { useFrame } from '@react-three/fiber';
// import { useGLTF } from '@react-three/drei';
// import * as THREE from 'three';

// /* -------------------------------------------------------------------------- */
// /*                                  CONFIG                                    */
// /* -------------------------------------------------------------------------- */

// const TILE_LENGTH = 20;
// const TILES_BEHIND = 40;
// const TILES_AHEAD  = 120;
// const SPEED        = 0.12;                     // world‑space units / frame (≈7 u/s)

// const LANES_X      = [-2.2, 0, 2.2];           // player lanes (L‑C‑R)
// const ROAD_EDGE_X  = 7.5;                      // where buildings sit
// const SKY_Y        = 12;                       // cloud height

// const COLLISION_Z  = 0.7;                      // forward/behind tolerance
// const COLLISION_X  = 0.75;                     // left/right tolerance

// const OBSTACLE_SPAWN_MS =  900;
// const CLOUD_SPAWN_MS    = 4000;
// const POOL_SIZE         = 60;

// /* -------------------------------------------------------------------------- */
// /*                            GROUND‑TILE COMPONENT                           */
// /* -------------------------------------------------------------------------- */

// export interface GroundTilesProps {
//   playerPos: THREE.Vector3;                      // shared player position ref
//   setRefs?: (refs: THREE.Object3D[]) => void;    // emit all active obstacles
// }

// export default function GroundTiles({ playerPos, setRefs }: GroundTilesProps) {
//   /* ------------------------------ refs & pools ---------------------------- */
//   const offsetZ   = useRef(0);
//   const pool      = useRef<THREE.Object3D[]>([]);
//   const active    = useRef<THREE.Object3D[]>([]);
//   const clouds    = useRef<THREE.Object3D[]>([]);

//   /* ------------------------------- assets --------------------------------- */
//   const { scene: road  }         = useGLTF('/models/country.glb');
//   const { scene: cone  }         = useGLTF('/models/RoadCone.glb');
//   const { scene: goldBag }       = useGLTF('/models/GoldBag.glb');        // big coin
//   const { scene: coinSingle }    = useGLTF('/models/coin.glb');     // NEW tiny coin
//   // const { scene: grass }         = useGLTF('/models/GrassTile.glb');
//   const { scene: buildingTall }  = useGLTF('/models/LargeBuilding2.glb');     // NEW side deco
//   const { scene: buildingMed }   = useGLTF('/models/LargeBuilding.glb');
//   const { scene: cloudModel }    = useGLTF('/models/cloud.glb');          // NEW sky deco

//   /* --------------------------- static background -------------------------- */
//   const background = useMemo(() => {
//     const tiles: THREE.Object3D[] = [];

//     for (let i = -TILES_BEHIND; i < TILES_AHEAD; i++) {
//       // road strip (centre)
//       const t = road.clone();
//       t.rotation.set(0, Math.PI * 1.5, 0);
//       t.scale.setScalar(1);
//       t.position.set(0, -1.2, -i * TILE_LENGTH);
//       tiles.push(t);

//       // grass L/R
//       // const gL = grass.clone();
//       // const gR = grass.clone();
//       // gL.scale.setScalar(2.4);
//       // gR.scale.setScalar(2.4);
//       // gL.position.set(LANES_X[0] - 5, -1.5, -i * TILE_LENGTH);
//       // gR.position.set(LANES_X[2] + 5, -1.5, -i * TILE_LENGTH);
//       // tiles.push(gL, gR);

//       // roadside buildings every 6th tile
//       if (i % 6 === 0) {
//         const bL = (i % 12 === 0 ? buildingTall : buildingMed).clone();
//         const bR =  buildingMed.clone();
//         const s   = 1.8 + Math.random() * 0.3;
//         bL.scale.setScalar(s);
//         bR.scale.setScalar(1.6);
//         bL.position.set(-ROAD_EDGE_X, -1, -i * TILE_LENGTH);
//         bR.position.set( ROAD_EDGE_X, -1, -i * TILE_LENGTH);
//         tiles.push(bR);
//       }
//     }

//     return tiles;
//   }, [road, buildingMed]);

//   /* --------------------------- obstacle factory --------------------------- */
//   const obstaclePool = useMemo(() => [
//     { scene: cone,       scale: 1.4, type: 'obstacle' },
//     { scene: goldBag,    scale: 1.9, type: 'coin'     },
//     { scene: coinSingle, scale: 1.1, type: 'coin'     },
//   ], [cone, goldBag, coinSingle]);

//   const acquireMesh = useCallback(() => {
//     if (pool.current.length) return pool.current.pop()!;
//     const o = obstaclePool[Math.floor(Math.random() * obstaclePool.length)];
//     const m = o.scene.clone();
//     m.userData.type = o.type;
//     m.scale.setScalar(o.scale);
//     return m;
//   }, [obstaclePool]);

//   const releaseMesh = useCallback((m: THREE.Object3D) => {
//     m.visible = false;
//     pool.current.push(m);
//   }, []);

//   /* --------------------------- obstacle spawner --------------------------- */
//   const spawnObstacles = useCallback(() => {
//     const lanesUsed = new Set<number>();
//     const n = Math.floor(Math.random() * 2) + 1;   // 1‑2 items

//     for (let i = 0; i < n; i++) {
//       let lane;
//       do lane = Math.floor(Math.random() * LANES_X.length);
//       while (lanesUsed.has(lane));
//       lanesUsed.add(lane);

//       const o = acquireMesh();
//       o.visible = true;
//       o.position.set(LANES_X[lane], -1, -(TILES_AHEAD - 3) * TILE_LENGTH);
//       active.current.push(o);
//     }

//     setRefs?.(active.current);
//   }, [acquireMesh, setRefs]);

//   /* ----------------------------- cloud spawner ---------------------------- */
//   const spawnCloud = useCallback(() => {
//     const c = cloudModel.clone();
//     const scale = 1.5 + Math.random();
//     c.scale.setScalar(scale);
//     c.position.set(
//       THREE.MathUtils.randFloatSpread(20), // random x across scene
//       SKY_Y + THREE.MathUtils.randFloatSpread(2),
//       -(TILES_AHEAD - 5) * TILE_LENGTH,
//     );
//     clouds.current.push(c);
//   }, [cloudModel]);

//   /* --------------------------- initial setup ------------------------------ */
//   useEffect(() => {
//     for (let i = 0; i < POOL_SIZE; i++) pool.current.push(acquireMesh());

//     const obsID   = setInterval(spawnObstacles, OBSTACLE_SPAWN_MS);
//     const cloudID = setInterval(spawnCloud,     CLOUD_SPAWN_MS);
//     return () => { clearInterval(obsID); clearInterval(cloudID); };
//   }, [acquireMesh, spawnObstacles, spawnCloud]);

//   /* ------------------------------ game loop ------------------------------ */
//   const scoreRef = useRef(0);

//   useFrame((_, delta) => {
//     const dz = SPEED * delta * 60;   // scale to ~60 fps

//     /* scroll background */
//     background.forEach(t => {
//       t.position.z += dz;
//       if (t.position.z > TILES_BEHIND * TILE_LENGTH)
//         t.position.z -= (TILES_BEHIND + TILES_AHEAD) * TILE_LENGTH;
//     });

//     /* animate clouds */
//     clouds.current = clouds.current.filter(c => {
//       c.position.z += dz * 0.6;                   // slower parallax
//       c.position.x += Math.sin(offsetZ.current * 0.05) * 0.002; // gentle drift
//       return c.position.z < 10;                   // keep until behind cam
//     });

//     /* move & test active obstacles */
//     active.current = active.current.filter(o => {
//       o.position.z += dz;
//       if (o.position.z > 5) { releaseMesh(o); return false; }

//       const zHit = Math.abs(o.position.z - playerPos.z) < COLLISION_Z;
//       const xHit = Math.abs(o.position.x - playerPos.x) < COLLISION_X;
//       if (zHit && xHit) {
//         if (o.userData.type === 'coin') {
//           scoreRef.current += 1;
//         } else {
//           alert(`💥 Collision! Final score: ${scoreRef.current}`);
//           scoreRef.current = 0;
//         }
//         releaseMesh(o);
//         return false;
//       }
//       return true;
//     });

//     offsetZ.current += dz;
//   });

//   /* -------------------------------- render -------------------------------- */
//   return (
//     <group>
//       {background.map((o, i) => <primitive key={`bg-${i}`} object={o} />)}
//       {clouds.current.map((c, i)    => <primitive key={`cl-${i}`} object={c} />)}
//       {[...active.current, ...pool.current].map((o, i) => (
//         <primitive key={`ob-${i}`} object={o} />
//       ))}
//     </group>
//   );
// }

// /* -------------------------------------------------------------------------- */
// /*                             ASSET PRELOADERS                               */
// /* -------------------------------------------------------------------------- */

// useGLTF.preload('/models/country.glb');
// useGLTF.preload('/models/RoadCone.glb');
// useGLTF.preload('/models/GoldBag.glb');
// useGLTF.preload('/models/coin.glb');
// useGLTF.preload('/models/GrassTile.glb');
// // useGLTF.preload('/models/Skyscraper.glb');
// useGLTF.preload('/models/city.glb');
// useGLTF.preload('/models/cloud.glb');



import { useRef, useMemo, useEffect, useCallback } from 'react';
import { useFrame } from '@react-three/fiber';
import { useGLTF } from '@react-three/drei';
import * as THREE from 'three';

/* -------------------------------------------------------------------------- */
/*                                  CONFIG                                    */
/* -------------------------------------------------------------------------- */

// PathStraight.glb is ~20 units long in Z – use that as tile size so segments
// butt-up perfectly and create a seamless endless road.
const TILE_LENGTH  = 40;
const TILES_BEHIND = 3;     // how many road tiles we keep behind camera
const TILES_AHEAD  = 6;    // … and in front (tweak for perf)
const SPEED        = 0.12;

const LANE_WIDTH   = 2.2;                         // metres between lane centres
const LANES_X      = [-LANE_WIDTH, 0, LANE_WIDTH];

const ROAD_WIDTH   = 40;                           // visual width of PathStraight
const GRASS_OFFSET = ROAD_WIDTH * 0.5 + 1;
const BUILDING_X   = GRASS_OFFSET + 1.5;
const SKY_Y        = 12;

const COLLISION_Z  = 0.9;
const COLLISION_X  = 0.9;

const OBSTACLE_SPAWN_MS = 900;
const CLOUD_SPAWN_MS    = 4000;
const POOL_SIZE         = 30;

/* -------------------------------------------------------------------------- */
export interface GroundTilesProps {
  playerPos: THREE.Vector3;
  setRefs?: (refs: THREE.Object3D[]) => void;
}

export default function GroundTiles({ playerPos, setRefs }: GroundTilesProps) {
  const pool      = useRef<THREE.Object3D[]>([]);
  const active    = useRef<THREE.Object3D[]>([]);
  const clouds    = useRef<THREE.Object3D[]>([]);

  /* ------------------------------- assets -------------------------------- */
  const { scene: road        } = useGLTF('/models/country.glb');
  const { scene: cone        } = useGLTF('/models/RoadCone.glb');
  const { scene: goldBag     } = useGLTF('/models/GoldBag.glb');
  const { scene: coinSingle  } = useGLTF('/models/coin.glb');
  const { scene: grass       } = useGLTF('/models/GrassTile.glb');
  // const { scene: skyscraper  } = useGLTF('/models/Skyscraper.glb');
  const { scene: block       } = useGLTF('/models/LargeBuilding.glb');
  const { scene: cloudModel  } = useGLTF('/models/cloud.glb');

  /* --------------------------- static background ------------------------- */
  const background = useMemo(() => {
    const objs: THREE.Object3D[] = [];

    for (let i = -TILES_BEHIND; i < TILES_AHEAD; i++) {
      /* centre road tile */
      const r = road.clone(true);
      r.rotation.set(0, 0, 0);
      r.position.set(0, -2, -i * TILE_LENGTH);
      objs.push(r);

      /* grass */
      ['L', 'R'].forEach(side => {
        const g = grass.clone();
        g.position.set(
          side === 'L' ? -GRASS_OFFSET : GRASS_OFFSET,
          -1.5,
          -i * TILE_LENGTH
        );
        objs.push(g);
      });

      /* buildings every third tile so they line up visually */
      // if (i % 3 === 0) {
      //   const left  = (i % 6 === 0 ? skyscraper : block).clone();
      //   const right = (i % 6 === 0 ? block      : skyscraper).clone();
      //   const s     = 1.8 + Math.random() * 0.3;
      //   left .scale.setScalar(s);
      //   right.scale.setScalar(s);
      //   left .position.set(-BUILDING_X, -1, -i * TILE_LENGTH);
      //   right.position.set( BUILDING_X, -1, -i * TILE_LENGTH);
      //   objs.push(left, right);
      // }
    }
    return objs;
  }, [road, grass,  block]);

  /* --------------------------- obstacle pool ----------------------------- */
  const obstacleDefs = useMemo(() => [
    { mesh: cone,       scale: 1.4, type: 'obstacle' },
    { mesh: goldBag,    scale: 1.9, type: 'coin'     },
    { mesh: coinSingle, scale: 1.4, type: 'coin'     },
  ], [cone, goldBag, coinSingle]);

  const acquire = useCallback(() => {
    if (pool.current.length) return pool.current.pop()!;
    const d = obstacleDefs[Math.floor(Math.random() * obstacleDefs.length)];
    const m = d.mesh.clone();
    m.userData.type = d.type;
    m.scale.setScalar(d.scale);
    return m;
  }, [obstacleDefs]);

  const release = useCallback((m: THREE.Object3D) => {
    m.visible = false;
    pool.current.push(m);
  }, []);

  /* ---------------------------- spawners --------------------------------- */
  const spawnObstacles = useCallback(() => {
    const used = new Set<number>();
    const count = 1 + Math.floor(Math.random() * 2);
    for (let i = 0; i < count; ++i) {
      let lane;
      do lane = Math.floor(Math.random() * LANES_X.length);
      while (used.has(lane));
      used.add(lane);

      const o = acquire();
      o.visible = true;
      o.position.set(
        LANES_X[lane],
        -0.7,
        -(TILES_AHEAD - 2) * TILE_LENGTH
      );
      active.current.push(o);
    }
    setRefs?.(active.current);
  }, [acquire, setRefs]);

  const spawnCloud = useCallback(() => {
    const c = cloudModel.clone();
    const s = 1.5 + Math.random();
    c.scale.setScalar(s);
    c.position.set(
      THREE.MathUtils.randFloatSpread(20),
      SKY_Y + THREE.MathUtils.randFloatSpread(2),
      -(TILES_AHEAD - 5) * TILE_LENGTH
    );
    clouds.current.push(c);
  }, [cloudModel]);

  /* ---------------------------- init timers ------------------------------ */
  useEffect(() => {
    for (let i = 0; i < POOL_SIZE; i++) pool.current.push(acquire());
    const obsT = setInterval(spawnObstacles, OBSTACLE_SPAWN_MS);
    const cldT = setInterval(spawnCloud,     CLOUD_SPAWN_MS);
    return () => { clearInterval(obsT); clearInterval(cldT); };
  }, [acquire, spawnObstacles, spawnCloud]);

  /* ------------------------------ frame ---------------------------------- */
  const score = useRef(0);

  useFrame((_, dt) => {
    const dz = SPEED * dt * 60;

    /* scroll background tiles */
    background.forEach(o => {
      o.position.z += dz;
      if (o.position.z >  TILES_BEHIND * TILE_LENGTH)
        o.position.z -= (TILES_BEHIND + TILES_AHEAD) * TILE_LENGTH;
    });

    /* clouds */
    clouds.current = clouds.current.filter(c => {
      c.position.z += dz * 0.6;
      return c.position.z < 10;              // keep until behind camera
    });

    /* obstacles */
    active.current = active.current.filter(o => {
      o.position.z += dz;
      if (o.position.z > 5) { release(o); return false; }

      const hitZ = Math.abs(o.position.z - playerPos.z) < COLLISION_Z;
      const hitX = Math.abs(o.position.x - playerPos.x) < COLLISION_X;

      if (hitZ && hitX) {
        if (o.userData.type === 'coin') {
          score.current += 1;
        } else {
          alert(`💥 Collision! Final score: ${score.current}`);
          score.current = 0;
        }
        release(o);
        return false;
      }
      return true;
    });
  });

  /* ------------------------------ render --------------------------------- */
  return (
    <group>
      {background.map((o, i) => <primitive key={`bg-${i}`} object={o} />)}
      {clouds.current.map((c, i)    => <primitive key={`cl-${i}`} object={c} />)}
      {[...active.current, ...pool.current].map((o, i) => (
        <primitive key={`ob-${i}`} object={o} />
      ))}
    </group>
  );
}

/* -------------------------------------------------------------------------- */
/*                             ASSET PRELOADERS                               */
/* -------------------------------------------------------------------------- */

useGLTF.preload('/models/country.glb');
useGLTF.preload('/models/RoadCone.glb');
useGLTF.preload('/models/GoldBag.glb');
useGLTF.preload('/models/coin.glb');
useGLTF.preload('/models/GrassTile.glb');
// useGLTF.preload('/models/.glb');
useGLTF.preload('/models/LargeBuilding.glb');
useGLTF.preload('/models/cloud.glb');
