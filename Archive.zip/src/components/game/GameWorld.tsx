// // // components/game3d/GameWorld.tsx
// import { Canvas } from '@react-three/fiber';
// import { Suspense } from 'react';
// // import { OrbitControls, Environment } from '@react-three/drei';
// // import PlayerModel from './PlayerModel.tsx';
// // import GroundTiles from './GroundTiles.tsx';
// // import Obstacles from './Obstacles';
// // // import ObstaclesWithRoad from "./GroundTiles.tsx"
// // // import Skybox from './Skybox.tsx';

// // export default function GameWorld({ onGameEnd }: { onGameEnd: (score: number) => void }) {
// //   return (
// //     // <Canvas camera={{ position: [0, 2, 6], fov: 60 }}>
// //     <Canvas camera={{ position: [0, 6, 8], fov: 70 }}>

// //       <ambientLight intensity={0.4} />
// //       <directionalLight position={[2, 10, 5]} intensity={1.2} />
      
// //       <Suspense fallback={null}>
// //         <Environment preset="sunset" />
// //         <GroundTiles />
// //         <PlayerModel />
// //         {/* <Obstacles /> */}
// //       </Suspense>

// //       <OrbitControls enableZoom={false} enablePan={false} />
// //     </Canvas>
// //   );
// // }
// import { useState, useRef } from 'react';
// // import { Canvas } from '@react-three/fiber';
// import { OrbitControls, Environment } from '@react-three/drei';
// import * as THREE from 'three';
// import PlayerModel from './PlayerModel';
// import GroundTiles from './GroundTiles'

// export default function GameWorld() {
//   const [obstacleRefs, setObstacleRefs] = useState<THREE.Object3D[]>([]);
//   const onGameEnd = () => alert("💥 Collision! Game Over");

//   return (
//     <Canvas camera={{ position: [0, 5, 10], fov: 60 }}>
//       <ambientLight intensity={0.4} />
//       <directionalLight position={[2, 10, 5]} intensity={1.2} />

//       <Suspense fallback={null}>
//         <Environment preset="sunset" />
//         <GroundTiles setRefs={setObstacleRefs} playerPos={new Vector3} />
//         <PlayerModel obstacles={obstacleRefs} onHit={onGameEnd} />
//       </Suspense>

//       <OrbitControls enableZoom={false} enablePan={false} />
//     </Canvas>
//   );
// }
import { Suspense, useRef, useState } from 'react';
import { Canvas } from '@react-three/fiber';
import { OrbitControls, Environment } from '@react-three/drei';
import * as THREE from 'three';

import PlayerModel from './PlayerModel';
import GroundTiles from './GroundTiles';

export default function GameWorld() {
  /* one shared Vector3 instance for the player’s world-space position */
  const playerPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, -1, 2)); // z≈camera, tweak as needed

  const [obstacleRefs, setObstacleRefs] = useState<THREE.Object3D[]>([]);
  const onGameEnd = () => alert('💥 Collision! Game Over');

  return (
    <Canvas camera={{ position: [0, 5, 10], fov: 60 }}>
      <ambientLight intensity={0.4} />
      <directionalLight position={[2, 10, 5]} intensity={1.2} />

      <Suspense fallback={null}>
        <Environment preset="sunset" />

        {/* pass the SAME vector instance to GroundTiles */}
        <GroundTiles playerPos={playerPosRef.current} setRefs={setObstacleRefs} />

        {/* give PlayerModel a ref so it can mutate the vector every frame */}
        <PlayerModel
          posRef={playerPosRef}
          obstacles={obstacleRefs}
          onHit={onGameEnd}
        />
      </Suspense>

      <OrbitControls enableZoom={false} enablePan={false} />
    </Canvas>
  );
}
