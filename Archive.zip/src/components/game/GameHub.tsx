
import { useState, useEffect } from "react";
import type { Session } from "@/integrations/supabase/client";
import { BottomNavigation } from "@/components/navigation/BottomNavigation";
import { GameScreen } from "@/components/game/GameScreen";
import { ProfileScreen } from "@/components/profile/ProfileScreen";
import { LeaderboardScreen } from "@/components/leaderboard/LeaderboardScreen";
import { TournamentScreen } from "@/components/tournament/TournamentScreen";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface Profile {
  id: string;
  username: string;
  avatar_url?: string;
  total_coins: number;
  tournament_active: boolean;
  created_at: string;
}

export const GameHub = ({ session }: { session: Session }) => {
  const [activeTab, setActiveTab] = useState("game");
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getProfile();
  }, [session]);

  const getProfile = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', session.user.id)
        .single();

      if (error && error.code === 'PGRST116') {
        // Profile doesn't exist, create one
        const { data: newProfile, error: insertError } = await supabase
          .from('profiles')
          .insert([
            {
              id: session.user.id,
              username: session.user.email?.split('@')[0] || 'Player',
              total_coins: 0,
              tournament_active: false,
            }
          ])
          .select()
          .single();

        if (insertError) throw insertError;
        setProfile(newProfile);
      } else if (error) {
        throw error;
      } else {
        setProfile(data);
      }
    } catch (error: any) {
      console.error('Error loading profile:', error);
      toast.error("Failed to load profile");
    } finally {
      setLoading(false);
    }
  };

  const updateProfile = (updatedProfile: Profile) => {
    setProfile(updatedProfile);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
      </div>
    );
  }

  const renderScreen = () => {
    switch (activeTab) {
      case "game":
        return <GameScreen profile={profile} updateProfile={updateProfile} />;
      case "leaderboard":
        return <LeaderboardScreen />;
      case "tournament":
        return <TournamentScreen profile={profile} updateProfile={updateProfile} />;
      case "profile":
        return <ProfileScreen profile={profile} updateProfile={updateProfile} session={session} />;
      default:
        return <GameScreen profile={profile} updateProfile={updateProfile} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-blue-900 to-indigo-900 pb-20">
      {renderScreen()}
      <BottomNavigation activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};
