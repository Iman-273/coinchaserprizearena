
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Crown, DollarSign, Calendar, Users, Trophy, Star } from "lucide-react";
import { toast } from "sonner";

interface Profile {
  id: string;
  username: string;
  avatar_url?: string;
  total_coins: number;
  tournament_active: boolean;
  created_at: string;
}

interface TournamentScreenProps {
  profile: Profile | null;
  updateProfile: (profile: Profile) => void;
}

export const TournamentScreen = ({ profile, updateProfile }: TournamentScreenProps) => {
  const [loading, setLoading] = useState(false);

  const handleJoinTournament = async () => {
    setLoading(true);
    
    // This will be replaced with actual Stripe payment integration
    setTimeout(() => {
      toast.success("Tournament access purchased! You can now compete for prizes.");
      if (profile) {
        updateProfile({ ...profile, tournament_active: true });
      }
      setLoading(false);
    }, 2000);
  };

  const handleManageBilling = () => {
    toast.info("Billing management will be available soon!");
  };

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">Tournament</h1>
        <p className="text-blue-200">Compete for real cash prizes every week</p>
      </div>

      {/* Tournament Status */}
      <Card className={`backdrop-blur-sm ${
        profile?.tournament_active 
          ? "bg-gradient-to-r from-green-500/20 to-blue-500/20 border-green-400/30"
          : "bg-gradient-to-r from-red-500/20 to-orange-500/20 border-red-400/30"
      }`}>
        <CardHeader>
          <CardTitle className=" flex items-center gap-2">
            <Crown className="h-5 w-5" />
            Your Tournament Status
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-center">
            <p className="text-3xl font-bold  mb-2">
              {profile?.tournament_active ? "ACTIVE" : "INACTIVE"}
            </p>
            <p className="text-gret">
              {profile?.tournament_active 
                ? "You're competing in this week's tournament!"
                : "Join the tournament to compete for prizes"
              }
            </p>
          </div>
          
          {!profile?.tournament_active && (
            <Button 
              onClick={handleJoinTournament}
              disabled={loading}
              className="w-full bg-gradient-to-r from-yellow-400 to-orange-500 hover:from-yellow-500 hover:to-orange-600  font-bold py-3"
            >
              {loading ? "Processing Payment..." : "Join Tournament - $2.00"}
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Current Week Prizes */}
      <Card className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border-yellow-400/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            This Week's Prizes
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-2">
                  <span className="text-white font-bold">1st</span>
                </div>
                <p className="text-2xl font-bold text-yellow-400">$2,500</p>
                <p className="text-sm text-yellow-800">First Place</p>
              </div>
              <div className="text-center">
                <div className="bg-gradient-to-r from-gray-400 to-gray-600 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-2">
                  <span className="text-white font-bold">2nd</span>
                </div>
                <p className="text-2xl font-bold text-gray-300">$1,000</p>
                <p className="text-sm text-gray-600">Second Place</p>
              </div>
              <div className="text-center">
                <div className="bg-gradient-to-r from-amber-600 to-yellow-600 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-2">
                  <span className="text-white font-bold">3rd</span>
                </div>
                <p className="text-2xl font-bold text-amber-600">$500</p>
                <p className="text-sm text-amber-800">Third Place</p>
              </div>
            </div>
            
            <div className="text-center pt-4 border-t border-yellow-400/30">
              <p className="">Prize pool grows with more participants!</p>
              <p className="text-sm ">Current participants: 127 players</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tournament Info */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardContent className="p-4 text-center">
            <Calendar className="h-8 w-8 text-blue-400 mx-auto mb-2" />
            <p className="text-lg font-bold text-white">5 Days</p>
            <p className="text-sm text-blue-200">Until Reset</p>
          </CardContent>
        </Card>
        
        <Card className="bg-white/10 backdrop-blur-sm border-white/20">
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 text-purple-400 mx-auto mb-2" />
            <p className="text-lg font-bold text-white">127</p>
            <p className="text-sm text-blue-200">Active Players</p>
          </CardContent>
        </Card>
      </div>

      {/* Tournament Rules */}
      <Card className="bg-white/5 backdrop-blur-sm border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Star className="h-5 w-5" />
            How It Works
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="bg-yellow-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">1</div>
              <div>
                <p className="text-white font-medium">Pay $2 for tournament access</p>
                <p className="text-blue-200 text-sm">One-time payment gives you access forever</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-yellow-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">2</div>
              <div>
                <p className="text-white font-medium">Play tournament games</p>
                <p className="text-blue-200 text-sm">Only tournament games count toward rankings</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-yellow-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">3</div>
              <div>
                <p className="text-white font-medium">Compete for top 3</p>
                <p className="text-blue-200 text-sm">Weekly prizes awarded to highest scorers</p>
              </div>
            </div>
            
            <div className="flex items-start gap-3">
              <div className="bg-yellow-500 text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold">4</div>
              <div>
                <p className="text-white font-medium">Weekly reset</p>
                <p className="text-blue-200 text-sm">Scores reset every Sunday, fresh competition starts</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Billing Management */}
      {profile?.tournament_active && (
        <Card className="bg-white/5 backdrop-blur-sm border-white/10">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Billing & Account
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button 
              onClick={handleManageBilling}
              variant="outline"
              className="w-full bg-white/10 border-white/20 text-white"
            >
              Manage Billing
            </Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
