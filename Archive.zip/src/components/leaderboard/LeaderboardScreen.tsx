
import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Medal, Crown, Star } from "lucide-react";

interface LeaderboardEntry {
  rank: number;
  username: string;
  score: number;
  avatar?: string;
}

export const LeaderboardScreen = () => {
  const [weeklyLeaders, setWeeklyLeaders] = useState<LeaderboardEntry[]>([]);
  const [allTimeLeaders, setAllTimeLeaders] = useState<LeaderboardEntry[]>([]);

  // Mock data for now - will be replaced with real Supabase queries
  useEffect(() => {
    const mockWeekly: LeaderboardEntry[] = [
      { rank: 1, username: "SkyMaster", score: 2450 },
      { rank: 2, username: "CloudRunner", score: 2380 },
      { rank: 3, username: "StarJumper", score: 2290 },
      { rank: 4, username: "NeonSpeed", score: 2150 },
      { rank: 5, username: "AeroAce", score: 2050 },
      { rank: 6, username: "FlightHero", score: 1980 },
      { rank: 7, username: "JetStream", score: 1920 },
      { rank: 8, username: "WindWalker", score: 1850 },
    ];

    const mockAllTime: LeaderboardEntry[] = [
      { rank: 1, username: "LegendPlayer", score: 4850 },
      { rank: 2, username: "SkyMaster", score: 4200 },
      { rank: 3, username: "ProGamer", score: 3950 },
      { rank: 4, username: "CloudRunner", score: 3800 },
      { rank: 5, username: "EliteRunner", score: 3650 },
      { rank: 6, username: "StarJumper", score: 3400 },
      { rank: 7, username: "SpeedDemon", score: 3250 },
      { rank: 8, username: "AeroAce", score: 3100 },
    ];

    setWeeklyLeaders(mockWeekly);
    setAllTimeLeaders(mockAllTime);
  }, []);

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="h-6 w-6 text-yellow-400" />;
      case 2:
        return <Medal className="h-6 w-6 text-gray-300" />;
      case 3:
        return <Medal className="h-6 w-6 text-amber-600" />;
      default:
        return <Star className="h-6 w-6 text-blue-400" />;
    }
  };

  const getRankBg = (rank: number) => {
    switch (rank) {
      case 1:
        return "bg-gradient-to-r from-black-500/20 to-orange-500/20 border-yellow-400/30";
      case 2:
        return "bg-gradient-to-r from-black-500/20 to-slate-500/20 border-gray-400/30";
      case 3:
        return "bg-gradient-to-r from-black-600/20 to-yellow-600/20 border-amber-500/30";
      default:
        return "bg-white/5 border-white/10";
    }
  };

  const LeaderboardList = ({ leaders }: { leaders: LeaderboardEntry[] }) => (
    <div className="space-y-3">
      {leaders.map((entry) => (
        <Card 
          key={`${entry.rank}-${entry.username}`}
          className={`${getRankBg(entry.rank)} `}
        >
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-white/10">
                  {getRankIcon(entry.rank)}
                </div>
                <div>
                  <p className="font-bold text-white">#{entry.rank}</p>
                  <p className="text-sm text-blue-200">{entry.username}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-2xl font-bold text-white">{entry.score.toLocaleString()}</p>
                <p className="text-sm text-blue-200">points</p>
              </div>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">Leaderboard</h1>
        <p className="text-blue-200">See how you rank against other players</p>
      </div>

      {/* Prize Pool Info */}
      <Card className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border-yellow-400/30">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="h-5 w-5" />
            This Week's Prize Pool
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-2xl font-bold text-yellow-400">$2,500</p>
              <p className="text-sm text-yellow-800">1st Place</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-300">$1,000</p>
              <p className="text-sm text-gray-600">2nd Place</p>
            </div>
            <div>
              <p className="text-2xl font-bold text-amber-600">$500</p>
              <p className="text-sm text-amber-800">3rd Place</p>
            </div>
          </div>
          <p className="text-center  text-sm mt-4">
            Tournament resets every Sunday at midnight
          </p>
        </CardContent>
      </Card>

      {/* Leaderboard Tabs */}
      <Tabs defaultValue="weekly" className="w-full">
        <TabsList className="grid w-full grid-cols-2 bg-white/20">
          <TabsTrigger value="weekly" className="text-white">This Week</TabsTrigger>
          <TabsTrigger value="alltime" className="text-white">All Time</TabsTrigger>
        </TabsList>
        
        <TabsContent value="weekly" className="mt-4">
          <LeaderboardList leaders={weeklyLeaders} />
        </TabsContent>
        
        <TabsContent value="alltime" className="mt-4">
          <LeaderboardList leaders={allTimeLeaders} />
        </TabsContent>
      </Tabs>

      {/* Tournament Info */}
      <Card className="bg-white/5 backdrop-blur-sm border-white/10">
        <CardHeader>
          <CardTitle className="text-white text-lg">🏆 Tournament Rules</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="text-blue-200 text-sm space-y-1">
            <p>• Weekly tournaments start Monday, end Sunday</p>
            <p>• Only tournament games count toward rankings</p>
            <p>• Top 3 players receive cash prizes</p>
            <p>• $2 entry fee required to participate</p>
            <p>• Scores reset weekly, history is preserved</p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
