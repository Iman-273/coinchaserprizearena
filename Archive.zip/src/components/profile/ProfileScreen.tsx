
import { useState } from "react";
import type { Session } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { User, Coins, Trophy, Calendar, LogOut } from "lucide-react";

interface Profile {
  id: string;
  username: string;
  avatar_url?: string;
  total_coins: number;
  tournament_active: boolean;
  created_at: string;
}

interface ProfileScreenProps {
  profile: Profile | null;
  updateProfile: (profile: Profile) => void;
  session: Session;
}

export const ProfileScreen = ({ profile, updateProfile, session }: ProfileScreenProps) => {
  const [editing, setEditing] = useState(false);
  const [username, setUsername] = useState(profile?.username || "");
  const [loading, setLoading] = useState(false);

  const handleUpdateProfile = async () => {
    if (!profile) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('profiles')
        .update({ username })
        .eq('id', profile.id)
        .select()
        .single();

      if (error) throw error;
      
      updateProfile(data);
      setEditing(false);
      toast.success("Profile updated successfully!");
    } catch (error: any) {
      toast.error("Failed to update profile");
      console.error('Error updating profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSignOut = async () => {
    try {
      await supabase.auth.signOut();
      toast.success("Signed out successfully!");
    } catch (error: any) {
      toast.error("Failed to sign out");
    }
  };

  if (!profile) {
    return (
      <div className="p-4 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-white"></div>
      </div>
    );
  }

  return (
    <div className="p-4 space-y-6">
      {/* Header */}
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold text-white">Profile</h1>
        <p className="text-blue-200">Manage your account and view stats</p>
      </div>

      {/* Profile Card */}
      <Card className="bg-white/10 backdrop-blur-sm border-white/20">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <User className="h-5 w-5" />
            Player Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center space-x-4">
            <Avatar className="h-16 w-16">
              <AvatarImage src={profile.avatar_url} />
              <AvatarFallback className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white font-bold">
                {profile.username.substring(0, 2).toUpperCase()}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              {editing ? (
                <div className="space-y-2">
                  <Input
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    className="bg-white/20 border-white/30 text-white"
                    placeholder="Enter username"
                  />
                  <div className="flex gap-2">
                    <Button 
                      onClick={handleUpdateProfile}
                      disabled={loading}
                      size="sm"
                      className="bg-green-500 hover:bg-green-600"
                    >
                      {loading ? "Saving..." : "Save"}
                    </Button>
                    <Button 
                      onClick={() => setEditing(false)}
                      variant="outline"
                      size="sm"
                      className="bg-white/10 border-white/20 text-white"
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
              ) : (
                <div>
                  <h3 className="text-xl font-bold text-white">{profile.username}</h3>
                  <p className="text-blue-200">{session.user.email}</p>
                  <Button 
                    onClick={() => setEditing(true)}
                    variant="outline"
                    size="sm"
                    className="mt-2 bg-white/10 border-white/20 text-white"
                  >
                    Edit Profile
                  </Button>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4">
        <Card className="bg-gradient-to-r from-yellow-500/20 to-orange-500/20 backdrop-blur-sm border-yellow-400/30">
          <CardContent className="p-4 text-center">
            <Coins className="h-8 w-8 text-yellow-400 mx-auto mb-2" />
            <p className="text-2xl font-bold ">{profile.total_coins}</p>
            <p className="text-sm text-yellow-800">Total Coins</p>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500/20 to-pink-500/20 backdrop-blur-sm border-purple-400/30">
          <CardContent className="p-4 text-center">
            <Trophy className="h-8 w-8 text-purple-400 mx-auto mb-2" />
            <p className="text-2xl font-bold ">
              {profile.tournament_active ? "Active" : "Inactive"}
            </p>
            <p className="text-sm text-purple-800">Tournament</p>
          </CardContent>
        </Card>
      </div>

      {/* Account Info */}
      <Card className="bg-white/5 backdrop-blur-sm border-white/10">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Account Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-blue-200">Email:</span>
            <span className="text-white">{session.user.email}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-blue-200">Member since:</span>
            <span className="text-white">
              {new Date(profile.created_at).toLocaleDateString()}
            </span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-blue-200">Tournament Status:</span>
            <span className={`font-bold ${profile.tournament_active ? "text-green-400" : "text-red-400"}`}>
              {profile.tournament_active ? "Participating" : "Not Participating"}
            </span>
          </div>
        </CardContent>
      </Card>

      {/* Actions */}
      <div className="space-y-3">
        <Button 
          onClick={handleSignOut}
          variant="outline"
          className="w-full bg-red-500/20 border-red-400/30 text-red-200 hover:bg-red-500/30"
        >
          <LogOut className="h-4 w-4 mr-2" />
          Sign Out
        </Button>
      </div>
    </div>
  );
};
